# OptDSL

OptDSL is a Python-based domain-specific language for formulating optimisation problems that can be translated into MiniZinc models.

More information on this language and its translation can be found in [this link](https://epub.jku.at/doi/10.35011/risc.26-03). The grammar of the language can be found in [this link](https://epub.jku.at/doi/10.35011/risc.25-12).

## Requirements

- Python 3.10+
- MiniZinc installed on the system

## Installation

Install MiniZinc separately from the official MiniZinc distribution and confirm it is available:

```bash
minizinc --version
```

Clone the repository, create a virtual environment and install the Python dependencies:

```bash
git clone https://github.com/teresodra/OptDSL.git
cd OptDSL
python -m venv .venv
source .venv/bin/activate    # Linux/macOS
# .venv\Scripts\activate     # Windows
pip install -r requirements.txt
```

## Running the main example

The main entry point is:

```bash
python main.py
```

To optimise your own OptDSL formulations replace the string in `main.py` with your formulation