from .solver.DSL_solver import DSLSolver
from .translator.Objects.MiniZincTranslator import MiniZincTranslator